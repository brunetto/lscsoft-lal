#!/bin/bash -login
#
# $Id: segpagegen_S5.sh,v 1.3 2008/06/18 00:09:23 duncan Exp $
#
# Script which runs segpagegen on ldas-cit to generate the S5 segment dump
#
/usr1/ldbd/glue-1-17/bin/segpagegen --config-file /export/ldbd/etc/segpagegen_S5.ini
